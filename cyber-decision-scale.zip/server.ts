import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Initialize Gemini AI Client server-side
  const getGeminiClient = () => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.warn('GEMINI_API_KEY is not set in environment.');
      return null;
    }
    return new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  };

  // Health check API
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  // Decision Analysis Endpoint
  app.post('/api/decision/analyze', async (req, res) => {
    const { dilemma, optionA, optionB, mode, tone } = req.body;

    if (!dilemma) {
      return res.status(400).json({ error: '请提供您面临的纠结或选择！' });
    }

    const ai = getGeminiClient();

    // Fallback heuristic generator if Gemini key is not configured
    const generateFallbackDecision = () => {
      const isBinary = mode === 'binary' || (optionA && optionB);
      const optA = optionA || '放手去做 / 勇敢选择 A';
      const optB = optionB || '保持现状 / 稳妥选择 B';
      
      const hash = dilemma.split('').reduce((acc: number, char: string) => acc + char.charCodeAt(0), 0);
      const scoreA = 40 + (hash % 25);
      const scoreB = 100 - scoreA;
      const tiltAngle = Math.round((scoreA - scoreB) * 0.4);

      return {
        dilemma,
        optionA: optA,
        optionB: optB,
        scoreA,
        scoreB,
        tiltAngle,
        category: '生活/职场综合',
        angelPerspective: {
          title: '理性天使 · 长期价值视角',
          quote: `“从 3 年后的维度来看，任何带来增量认知的选择，试错成本都远低于错过成本。”`,
          arguments: [
            `选择【${scoreA >= scoreB ? optA : optB}】能最大化你掌控生活的主动权。`,
            '短期内可能会经历不适应，但边际收益会随着时间递增。',
            '将不确定性拆解为可量化的小目标，风险完全在可控范围内。',
          ],
          impact5Years: '五年后你会感谢今天没有在犹豫中消耗精神内耗。',
        },
        devilPerspective: {
          title: '毒舌恶魔 · 现实痛点与毒舌吐槽',
          quote: `“别装作很纠结了，你其实只是既想要收益又不想承担代价。”`,
          arguments: [
            `如果选【${optA}】，你真的能忍受前两个月的阵痛期而不是第三天就想放弃？`,
            `如果选【${optB}】，别在深夜又emo后悔自己当初为什么不敢冲。`,
            '选择困难症的本质不是选项太好，而是钱包和实力都不够支撑任性。',
          ],
          spicyRoast: '硬币抛上去的那一刻，你的潜意识早就在为某一方疯狂祈祷了。',
        },
        oraclePerspective: {
          title: '赛博预言家 · 平行宇宙与玄学征兆',
          prophecy: `宇宙全息模拟显示：在 87% 的平行宇宙中，选择主动出击的世界线最终满意度更高。`,
          cosmicSign: '今日宜断舍离，忌拖延反刍。顺风方向在东南，行动胜过千言万语。',
        },
        weightsA: [
          { label: '认知与个人成长', weight: 4, reason: '跳出舒适圈带来的不可替代经验' },
          { label: '潜在回报上限', weight: 5, reason: '收益天花板明显更高' },
          { label: '心理内耗解除', weight: 3, reason: '做了就不用天天念叨' },
        ],
        weightsB: [
          { label: '安全与风险缓冲', weight: 4, reason: '现阶段现金流与情绪缓冲更足' },
          { label: '即时舒适度', weight: 3, reason: '不需要重新适应新环境' },
        ],
        finalVerdict: {
          title: scoreA >= scoreB ? `倾斜裁决：偏向选择【${optA}】` : `倾斜裁决：偏向选择【${optB}】`,
          summary: `天平经综合博弈测算，【${scoreA >= scoreB ? optA : optB}】以 ${Math.max(scoreA, scoreB)}% 对 ${Math.min(scoreA, scoreB)}% 胜出。`,
          punchline: '人生最大的遗憾往往不是做错了什么，而是什么都没做却一直在耗尽心力。',
          recommendedOption: scoreA >= scoreB ? 'A' : 'B',
        },
        microAction: {
          step1: '设立 15 分钟倒计时：不再搜寻额外信息，关闭比较网页。',
          step2: `立刻执行【${scoreA >= scoreB ? optA : optB}】的最小启动动作（如发一条消息或写下第一步计划）。`,
          deadline: '今天 24:00 前完成最小启动动作。',
        },
        energyCost: 3,
        regretProbability: {
          ifChooseA: 28,
          ifChooseB: 65,
        },
      };
    };

    if (!ai) {
      return res.json(generateFallbackDecision());
    }

    try {
      const prompt = `你是一个兼具顶尖逻辑博弈、现实毒舌洞察与赛博玄学幽默的「赛博决策神殿裁决官」。
用户面临一个纠结/决策困境：
纠结议题："${dilemma}"
选项A: "${optionA || '执行/选择此项'}"
选项B: "${optionB || '放弃/维持现状'}"
模式: "${mode || 'comparison'}"
风格偏好: "${tone || 'balanced'}"

请针对该议题展开严密的「决策天平博弈分析」：
1. 给出双边倾向打分 scoreA (0-100) 与 scoreB (0-100，两者之和必须为100)。
2. 计算天平倾斜角度 tiltAngle (-25 到 25 之间的整数，正数偏向A，负数偏向B)。
3. 【理性天使】(Angel)：从长期价值、复利效应、成长维度提供沉着冷静的建设性支持。
4. 【毒舌恶魔】(Devil)：用一针见血、幽默辛辣、撕碎借口的大实话直击痛点与自欺欺人之处。
5. 【赛博预言家】(Oracle)：用平行宇宙、量子纠缠或赛博玄学给出充满哲思与神秘感的预言和今日吉凶征兆。
6. 为选项A和选项B分别提炼 2-4 个具体的决策砝码（含 label 简短标签、weight 1-5 权重分、reason 核心理由）。
7. 给出最终神圣裁决令（finalVerdict），包含金句一击（punchline）和推荐选项（A 或 B）。
8. 给出 24 小时内无需深思即可执行的「最小启动微行动指南」（microAction）。
9. 评估能量消耗指数 (energyCost, 1-5) 与后悔概率 (regretProbability)。

请严格以 JSON 格式输出，不要包含任何 markdown 代码块外部的多余文字。`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.7-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              dilemma: { type: Type.STRING },
              optionA: { type: Type.STRING },
              optionB: { type: Type.STRING },
              scoreA: { type: Type.INTEGER },
              scoreB: { type: Type.INTEGER },
              tiltAngle: { type: Type.INTEGER },
              category: { type: Type.STRING },
              angelPerspective: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  quote: { type: Type.STRING },
                  arguments: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                  },
                  impact5Years: { type: Type.STRING },
                },
                required: ['title', 'quote', 'arguments', 'impact5Years'],
              },
              devilPerspective: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  quote: { type: Type.STRING },
                  arguments: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                  },
                  spicyRoast: { type: Type.STRING },
                },
                required: ['title', 'quote', 'arguments', 'spicyRoast'],
              },
              oraclePerspective: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  prophecy: { type: Type.STRING },
                  cosmicSign: { type: Type.STRING },
                },
                required: ['title', 'prophecy', 'cosmicSign'],
              },
              weightsA: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    label: { type: Type.STRING },
                    weight: { type: Type.INTEGER },
                    reason: { type: Type.STRING },
                  },
                  required: ['label', 'weight', 'reason'],
                },
              },
              weightsB: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    label: { type: Type.STRING },
                    weight: { type: Type.INTEGER },
                    reason: { type: Type.STRING },
                  },
                  required: ['label', 'weight', 'reason'],
                },
              },
              finalVerdict: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  summary: { type: Type.STRING },
                  punchline: { type: Type.STRING },
                  recommendedOption: { type: Type.STRING },
                },
                required: ['title', 'summary', 'punchline', 'recommendedOption'],
              },
              microAction: {
                type: Type.OBJECT,
                properties: {
                  step1: { type: Type.STRING },
                  step2: { type: Type.STRING },
                  deadline: { type: Type.STRING },
                },
                required: ['step1', 'step2', 'deadline'],
              },
              energyCost: { type: Type.INTEGER },
              regretProbability: {
                type: Type.OBJECT,
                properties: {
                  ifChooseA: { type: Type.INTEGER },
                  ifChooseB: { type: Type.INTEGER },
                },
                required: ['ifChooseA', 'ifChooseB'],
              },
            },
            required: [
              'dilemma',
              'optionA',
              'optionB',
              'scoreA',
              'scoreB',
              'tiltAngle',
              'angelPerspective',
              'devilPerspective',
              'oraclePerspective',
              'weightsA',
              'weightsB',
              'finalVerdict',
              'microAction',
            ],
          },
        },
      });

      const rawText = response.text || '';
      const parsedData = JSON.parse(rawText);
      res.json(parsedData);
    } catch (err: any) {
      console.error('Gemini API execution error:', err);
      // If error occurs, smoothly return high-quality heuristic result
      res.json(generateFallbackDecision());
    }
  });

  // Vite middleware setup
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Cyber Decision Scale] Server running on http://localhost:${PORT}`);
  });
}

startServer();
