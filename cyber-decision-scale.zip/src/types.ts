export type AppMode = 'scale' | 'coin' | 'roulette' | 'archive' | 'monetization';

export type DecisionMode = 'binary' | 'single' | 'custom';

export interface WeightItem {
  id?: string;
  label: string;
  weight: number; // 1 to 5
  reason: string;
}

export interface AngelPerspective {
  title: string;
  quote: string;
  arguments: string[];
  impact5Years: string;
}

export interface DevilPerspective {
  title: string;
  quote: string;
  arguments: string[];
  spicyRoast: string;
}

export interface OraclePerspective {
  title: string;
  prophecy: string;
  cosmicSign: string;
}

export interface FinalVerdict {
  title: string;
  summary: string;
  punchline: string;
  recommendedOption: 'A' | 'B' | 'TIE' | string;
}

export interface MicroAction {
  step1: string;
  step2: string;
  deadline: string;
}

export interface DecisionResult {
  id: string;
  timestamp: number;
  dilemma: string;
  optionA: string;
  optionB: string;
  scoreA: number;
  scoreB: number;
  tiltAngle: number;
  category?: string;
  angelPerspective: AngelPerspective;
  devilPerspective: DevilPerspective;
  oraclePerspective: OraclePerspective;
  weightsA: WeightItem[];
  weightsB: WeightItem[];
  finalVerdict: FinalVerdict;
  microAction: MicroAction;
  energyCost?: number; // 1-5
  regretProbability?: {
    ifChooseA: number;
    ifChooseB: number;
  };
}

export interface RouletteOption {
  id: string;
  text: string;
  color: string;
  weight: number;
}

export interface PresetDilemma {
  id: string;
  title: string;
  category: 'career' | 'life' | 'emotion' | 'shopping' | 'tech';
  categoryLabel: string;
  optionA: string;
  optionB: string;
  tag: string;
}
